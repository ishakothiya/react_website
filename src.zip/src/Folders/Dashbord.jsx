import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import '../Folders/Css/Dashbord.css'



function Dashbord (props) {
    const navigate = useNavigate()

    const close = ()=>{
        localStorage.removeItem('islogin' )
        props.setislogin(false)
        navigate('/login')
    }
    return (

        <>
       
        <button type="button"  onClick={close}>Close</button>
               
            
        </>
    );
}

export default Dashbord